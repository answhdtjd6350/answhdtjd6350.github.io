const express = require('express');
const mysql = require('mysql');
const app = express();
const port = 3030;
const path = require('path');

app.use(express.json());

app.get('/', (req, res)=>
{
    res.sendFile(path.join(__dirname,'index.html'));
});

app.listen(port, ()=>
{
   console.log(`SERVER 실행됨 ${port}`); 
});