const messageElement = document.getElementById('message');
messageElement.innerHTML = 'Hi';